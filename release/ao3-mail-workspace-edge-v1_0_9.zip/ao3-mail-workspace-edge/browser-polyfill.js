"use strict";

/**
 * 极简 browser.* 兼容层（Edge / Chrome）。
 *
 * content.js 沿用 Firefox 的 `browser.*` + Promise 写法，Chromium 内核只提供
 * `chrome.*`。这里把 content.js 实际用到的几个接口包一层，保证 content.js
 * 与 Firefox 版本保持完全一致、无需改动。
 *
 * 该文件在 manifest 的 content_scripts.js 中排在 content.js 之前载入，
 * 二者共享同一个隔离世界的全局对象。
 */
(function () {
  const g = typeof globalThis !== "undefined" ? globalThis : window;

  // Firefox 本身已有 browser.*，直接跳过。
  if (typeof g.browser !== "undefined" && g.browser && g.browser.runtime) return;
  if (typeof chrome === "undefined" || !chrome.runtime) return;

  // 把回调式 API 包装成 Promise，并把 lastError 转成 reject。
  const promisify = (fn, thisArg) =>
    (...args) =>
      new Promise((resolve, reject) => {
        try {
          fn.call(thisArg, ...args, (result) => {
            const err = chrome.runtime.lastError;
            if (err) reject(new Error(err.message));
            else resolve(result);
          });
        } catch (error) {
          reject(error);
        }
      });

  const area = (store) => ({
    get: promisify(store.get, store),
    set: promisify(store.set, store),
    remove: promisify(store.remove, store),
    clear: promisify(store.clear, store)
  });

  g.browser = {
    runtime: {
      id: chrome.runtime.id,
      onMessage: chrome.runtime.onMessage,
      sendMessage: promisify(chrome.runtime.sendMessage, chrome.runtime),
      getURL: (path) => chrome.runtime.getURL(path)
    },
    storage: chrome.storage
      ? {
          local: area(chrome.storage.local),
          sync: chrome.storage.sync ? area(chrome.storage.sync) : undefined,
          onChanged: chrome.storage.onChanged
        }
      : undefined
  };
})();
