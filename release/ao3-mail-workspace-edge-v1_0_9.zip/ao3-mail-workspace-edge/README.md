# AO3 Mail Workspace（Edge 版）

把 AO3 页面包进一个类似桌面 Outlook 的邮件工作界面：左侧文件夹、中间邮件列表、右侧阅读窗格。作品正文和 AO3 链接仍然可以正常使用。

本包是 Firefox 版 v1.0.9 的 Edge（Chromium）移植版，界面与功能完全一致。

## 安装

1. 解压下载包，放到一个**不会被删除**的固定目录（Edge 每次启动都会从该目录读取，删了扩展就失效）。
2. 在 Edge 地址栏打开 `edge://extensions/`。
3. 打开左下角的「开发人员模式」。
4. 点击「加载解压缩的扩展」，选择解压出来的**文件夹**（就是包含 `manifest.json` 的那一层，不要选中 `manifest.json` 本身）。
5. 打开或刷新 AO3 页面。

装好后可以点扩展栏的拼图图标，把「AO3 Mail Workspace」旁边的眼睛/固定按钮打开，让蓝色信封图标常驻工具栏。

> 开发人员模式下 Edge 每次启动可能提示「禁用开发人员模式扩展」，点「保留」即可；不想看到提示就需要把扩展打包上传到 Edge 加载项商店。

同一份文件夹在 Chrome / 360 / QQ 等 Chromium 内核浏览器里用同样的方式加载也能直接跑。

## 使用

- 默认在 AO3 页面自动启用。
- 点击工具栏里的蓝色信封图标，可随时切换原界面/邮件界面。
- 快捷键：`Alt + Shift + M`（如与其他扩展冲突，可在 `edge://extensions/shortcuts` 改）。
- 页面右上角的「恢复 AO3」也可以立即还原。
- 状态会被记住，下次打开 AO3 时继续沿用。

### 邮件工具栏对应的 AO3 功能

- 「新邮件」：打开 AO3 新建作品页面。
- 「删除」：执行当前条目的 `Delete from History`。
- 「Bookmark」：为当前作品添加或编辑 AO3 Bookmark。
- 「标记」：执行 `Mark for Later` 或 `Mark as Read`。
- 「回复」：定位作品评论框；右侧下拉框可以查看评论。
- 「转发」：复制当前作品链接。
- 「RSS 源」：打开当前标签、系列等页面提供的 RSS/Atom 源。
- 顶部「搜索所有邮件」：输入关键词并按 Enter（或点击放大镜），跳转到 AO3 全站作品搜索结果。
- 「筛选」：仅筛选当前已经载入的邮件列表，不会跳转页面。
- AO3 History 页面会自动读取全部分页，不再只显示当前页的 20 条；载入时会显示页数进度。
- 在邮件列表中单击选择条目，双击打开作品；在 History 中选中后还可使用「删除」执行 `Delete from History`。
- 顶部 `EN / 中文` 按钮可以在中文、英文邮件界面之间切换，语言选择会被记住。
- 收件箱右上角提供「上一页」和「下一页」，每页显示 20 封邮件，可浏览全部已载入条目。
- 点击收件箱右上角的 `«`（最小化文件夹）可隐藏文件夹和邮件列表，获得更宽的阅读窗格；点击「展开文件夹」恢复。

## 覆盖范围

- 作品正文页：章节会显示成邮件列表，正文进入阅读窗格。
- 搜索、标签、收藏等列表页：作品会映射成邮件条目。
- 其他 AO3 页面：保留原内容并放入阅读窗格。

## 文件说明

- `manifest.json`：Edge 扩展配置（Manifest V3）
- `content.js`：页面转换逻辑（与 Firefox 版完全相同，未改一行）
- `mail-workspace.css`：邮件界面和 AO3 阅读样式（同上）
- `browser-polyfill.js`：`browser.*` → `chrome.*` 兼容层
- `background.js`：MV3 service worker，处理工具栏按钮和快捷键
- `icons/mail-16/32/48/128.png`：Chromium 只认位图图标
- `icons/mail.svg`：图标源文件（Edge 不直接使用，保留供以后重新导出）

仅匹配 `archiveofourown.org` 域名；不读取或发送页面内容，也不连接第三方服务。

## 与 Firefox 版的差异（移植记录）

| 项目 | Firefox v1.0.9 | Edge 版 |
| --- | --- | --- |
| Manifest 版本 | MV2 | MV3（Chromium 已停用 MV2） |
| 后台脚本 | 持久 background page | service worker |
| 工具栏按钮 | `browser_action` | `action` |
| 扩展 API | `browser.*`（Promise） | `chrome.*` + 兼容层还原成 `browser.*` |
| 权限 | `storage`、`tabs` | `storage` + `host_permissions`（MV3 要求显式声明主机权限；`tabs` 不再需要） |
| 图标 | SVG | PNG（Chromium 不支持 SVG 图标） |
| 安装方式 | 临时载入，退出即失效 | 加载解压缩扩展，重启后仍在 |
| Firefox 专用字段 | `browser_specific_settings` | 已移除 |

`content.js` 和 `mail-workspace.css` 保持逐字节一致，以后 Firefox 版更新这两个文件，直接覆盖过来即可，不需要二次修改。
