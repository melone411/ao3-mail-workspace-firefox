"use strict";

/**
 * MV3 service worker：工具栏按钮 + 快捷键。
 * 只负责向当前标签页的 content script 发一条切换消息。
 */

function toggleTab(tab) {
  if (!tab || typeof tab.id !== "number" || tab.id < 0) return;
  chrome.tabs.sendMessage(tab.id, { type: "AO3MAIL_TOGGLE" }, () => {
    // 页面不是 AO3、或 content script 尚未注入时会报错，忽略即可。
    void chrome.runtime.lastError;
  });
}

chrome.action.onClicked.addListener(toggleTab);

chrome.commands.onCommand.addListener((command) => {
  if (command !== "toggle-mail-workspace") return;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    void chrome.runtime.lastError;
    toggleTab(tabs && tabs[0]);
  });
});
